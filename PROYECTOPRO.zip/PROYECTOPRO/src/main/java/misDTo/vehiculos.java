/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package misDTo;

import conexionPostgres.bd;
import java.awt.TextField;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author danie
 */
public class vehiculos {
    
    private String NoMulta;
    private String fechayhora;
    private String agenteEncargado;
     private String departamento;
     private String municipio;
     private String direccion;
     private String DpiConductor;
     private String NoLicencia;
      private String NombreConductor;
      private String placa;      
       private String Marca;       
       private String LineaVehic;       
      private String Color;       
       private String EstadoMulta;
        private String Justificacion;
        
        
        
        
        
        
        
        
        
        
        
        
        

    public String getNoMulta() {
        return NoMulta;
    }

    public void setNoMulta(String NoMulta) {
        this.NoMulta = NoMulta;
    }

    public String getFechayhora() {
        return fechayhora;
    }

    public void setFechayhora(String fechayhora) {
        this.fechayhora = fechayhora;
    }

    public String getAgenteEncargado() {
        return agenteEncargado;
    }

    public void setAgenteEncargado(String agenteEncargado) {
        this.agenteEncargado = agenteEncargado;
    }

    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    public String getMunicipio() {
        return municipio;
    }

    public void setMunicipio(String municipio) {
        this.municipio = municipio;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getDpiConductor() {
        return DpiConductor;
    }

    public void setDpiConductor(String DpiConductor) {
        this.DpiConductor = DpiConductor;
    }

    public String getNoLicencia() {
        return NoLicencia;
    }

    public void setNoLicencia(String NoLicencia) {
        this.NoLicencia = NoLicencia;
    }

    public String getNombreConductor() {
        return NombreConductor;
    }

    public void setNombreConductor(String NombreConductor) {
        this.NombreConductor = NombreConductor;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getMarca() {
        return Marca;
    }

    public void setMarca(String Marca) {
        this.Marca = Marca;
    }

    public String getLineaVehic() {
        return LineaVehic;
    }

    public void setLineaVehic(String LineaVehic) {
        this.LineaVehic = LineaVehic;
    }

    public String getColor() {
        return Color;
    }

    public void setColor(String Color) {
        this.Color = Color;
    }

    public String getEstadoMulta() {
        return EstadoMulta;
    }

    public void setEstadoMulta(String EstadoMulta) {
        this.EstadoMulta = EstadoMulta;
    }

    public String getJustificacion() {
        return Justificacion;
    }

    public void setJustificacion(String Justificacion) {
        this.Justificacion = Justificacion;
    }
              
    
    
    public void MostrarMultas(JTable paramTablaTotalMultas){
        
        bd objetoConexion= new bd();
          DefaultTableModel modelo= new DefaultTableModel();
      
      String sql= "";
      modelo.addColumn("id_multa");
      modelo.addColumn("fecha_hora");
      modelo.addColumn("agente_encargado");
      modelo.addColumn("departamento");
      modelo.addColumn("municipio");
      modelo.addColumn("direccion_exacta");
      modelo.addColumn("dpi_conductor");
      modelo.addColumn("no_licencia");
      modelo.addColumn("nombre_conductor");
      modelo.addColumn("placa_vehiculo");
      modelo.addColumn("marca_vehiculo");
      modelo.addColumn("linea_vehiculo");
      modelo.addColumn("color_vehiculo");
      modelo.addColumn("estado_multa");
      modelo.addColumn("justificacion_anulado"); 
      
      paramTablaTotalMultas.setModel(modelo);
      
      
      sql ="select * from multas;";
      
      
      
      String [] datos = new String[14];
      
      Statement st;
      
      
      try{
          
          st=objetoConexion.establecerConexion().createStatement();
          ResultSet rs= st.executeQuery(sql);
          
          while (rs.next()){
              
              datos[0]= rs.getString(1);
              datos[1]= rs.getString(2);
              datos[2]= rs.getString(3);
               datos[3]= rs.getString(4);
              datos[4]= rs.getString(5);
               datos[5]= rs.getString(6);
              datos[6]= rs.getString(7);
               datos[7]= rs.getString(8);
              datos[8]= rs.getString(9);
              datos[9]= rs.getString(10);
              datos[10]= rs.getString(11);
              datos[11]= rs.getString(12);
              datos[12]= rs.getString(13);
              datos[13]= rs.getString(14);
              
              modelo.addRow(datos);
          }
          
          paramTablaTotalMultas.setModel(modelo);
           
          
      }catch (Exception e){
          JOptionPane.showMessageDialog(null,"error:"+ e.toString());
      }
        
        
    }
      public void SeleccionarMulta(JTable paramTablaMulta, 
                             JTextField paramNoMulta, 
                             JTextField paramFechaHora, 
                             JTextField paramAgenteEncargado, 
                             JTextField paramDepartamento, 
                             JTextField paramMunicipio, 
                             JTextField paramDireccionExacta, 
                             JTextField paramDPI, 
                             JTextField paramNoLicencia, 
                             JTextField paramNombreConductor, 
                             JTextField paramPlaca, 
                             JTextField paramMarca, 
                             JTextField paramLinea, 
                             JTextField paramColor, 
                             JTextField paramEstadoMulta, 
                             JTextField paramJustificacionAnulada) {
    try {
        int fila = paramTablaMulta.getSelectedRow();

        if (fila >= 0) {
            // Asignar valores a los JTextFields desde la tabla
            paramNoMulta.setText(paramTablaMulta.getValueAt(fila, 0).toString());
            paramFechaHora.setText(paramTablaMulta.getValueAt(fila, 1).toString());
            paramAgenteEncargado.setText(paramTablaMulta.getValueAt(fila, 2).toString());
            paramDepartamento.setText(paramTablaMulta.getValueAt(fila, 3).toString());
            paramMunicipio.setText(paramTablaMulta.getValueAt(fila, 4).toString());
            paramDireccionExacta.setText(paramTablaMulta.getValueAt(fila, 5).toString());
            paramDPI.setText(paramTablaMulta.getValueAt(fila, 6).toString());
            paramNoLicencia.setText(paramTablaMulta.getValueAt(fila, 7).toString());
            paramNombreConductor.setText(paramTablaMulta.getValueAt(fila, 8).toString());
            paramPlaca.setText(paramTablaMulta.getValueAt(fila, 9).toString());
            paramMarca.setText(paramTablaMulta.getValueAt(fila, 10).toString());
            paramLinea.setText(paramTablaMulta.getValueAt(fila, 11).toString());
            paramColor.setText(paramTablaMulta.getValueAt(fila, 12).toString());
            paramEstadoMulta.setText(paramTablaMulta.getValueAt(fila, 13).toString());
            paramJustificacionAnulada.setText(paramTablaMulta.getValueAt(fila, 14).toString());
        } else {
            JOptionPane.showMessageDialog(null, "Fila no seleccionada");
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error: " + e.toString());
    }
}

public void insertarMulta(Timestamp paramFechaHora,
                               String paramAgente,
                               JComboBox<String> paramDepartamento,
                               JComboBox<String> paramMunicipio,
                               String paramDireccion,
                               String paramDpi,
                               String paramLicencia,
                               String paramConductor,
                               String paramPlaca,
                               String paramMarca,
                               String paramLinea,
                               String paramColor,
                               String paramEstado,
                               String paramJustificacion) {

        // Validaciones para asegurarse de que los campos no estén vacíos
        if (paramFechaHora.after(paramFechaHora)) {
            JOptionPane.showMessageDialog(null, "El campo de fecha y hora no puede estar vacío.");
            return;
        }
        if (paramAgente.isEmpty()) {
            JOptionPane.showMessageDialog(null, "El campo de agente encargado no puede estar vacío.");
            return;
        }
        if (paramDepartamento.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(null, "El departamento no puede estar vacío.");
            return;
        }
        if (paramMunicipio.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(null, "El municipio no puede estar vacío.");
            return;
        }
        if (paramDireccion.isEmpty()) {
            JOptionPane.showMessageDialog(null, "El campo de dirección no puede estar vacío.");
            return;
        }
        if (paramDpi.isEmpty()) {
            JOptionPane.showMessageDialog(null, "El campo de DPI no puede estar vacío.");
            return;
        }
        if (paramLicencia.isEmpty()) {
            JOptionPane.showMessageDialog(null, "El campo de licencia no puede estar vacío.");
            return;
        }
        if (paramConductor.isEmpty()) {
            JOptionPane.showMessageDialog(null, "El campo de nombre del conductor no puede estar vacío.");
            return;
        }
        if (paramPlaca.isEmpty()) {
            JOptionPane.showMessageDialog(null, "El campo de placa no puede estar vacío.");
            return;
        }
        if (paramMarca.isEmpty()) {
            JOptionPane.showMessageDialog(null, "El campo de marca no puede estar vacío.");
            return;
        }
        if (paramLinea.isEmpty()) {
            JOptionPane.showMessageDialog(null, "El campo de línea no puede estar vacío.");
            return;
        }
        if (paramColor.isEmpty()) {
            JOptionPane.showMessageDialog(null, "El campo de color no puede estar vacío.");
            return;
        }
        if (paramEstado.isEmpty()) {
            JOptionPane.showMessageDialog(null, "El campo de estado no puede estar vacío.");
            return;
        }
        if (paramJustificacion.isEmpty()) {
            JOptionPane.showMessageDialog(null, "El campo de justificación no puede estar vacío.");
            return;
        }

  

        // Conexión a la base de datos
        bd objetoConexion = new bd();
        String consulta = "INSERT INTO multas (fecha_hora, agente_encargado, departamento, municipio, direccion_exacta, "
                        + "dpi_conductor, no_licencia, nombre_conductor, placa_vehiculo, marca_vehiculo, linea_vehiculo, "
                        + "color_vehiculo, estado_multa, justificacion_anulado) "
                        + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";

        try {
            CallableStatement cs = objetoConexion.establecerConexion().prepareCall(consulta);

            // Asignar los valores en la consulta
        cs.setTimestamp(1, paramFechaHora); // Se utiliza el Timestamp directamente
        cs.setString(2, paramAgente);
        cs.setString(3, paramDepartamento.getSelectedItem().toString());
        cs.setString(4, paramMunicipio.getSelectedItem().toString());
        cs.setString(5, paramDireccion);
        cs.setString(6, paramDpi);
        cs.setString(7, paramLicencia);
        cs.setString(8, paramConductor);
        cs.setString(9, paramPlaca);
        cs.setString(10, paramMarca);
        cs.setString(11, paramLinea);
        cs.setString(12, paramColor);
        cs.setString(13, paramEstado);
        cs.setString(14, paramJustificacion);
            // Ejecutar la consulta
            cs.executeUpdate();
            
            // Mensaje de éxito
            JOptionPane.showMessageDialog(null, "Se insertó correctamente");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: " + e.toString());
        }
    }
    
    

public void eliminarMulta(int idMulta) {
    // Crea una instancia de la clase de conexión a la base de datos
    bd objetoConexion = new bd();
    
    // Consulta SQL para eliminar una multa según su ID
    String consulta = "DELETE FROM multas WHERE id_multa = ?";

    try {
        // Preparar la consulta
        CallableStatement cs = objetoConexion.establecerConexion().prepareCall(consulta);

        // Asignar el valor del ID de la multa
        cs.setInt(1, idMulta);

        // Ejecutar la consulta
        int filasAfectadas = cs.executeUpdate();

        // Verificar si se eliminó la multa
        if (filasAfectadas > 0) {
            JOptionPane.showMessageDialog(null, "Multa eliminada correctamente.");
        } else {
            JOptionPane.showMessageDialog(null, "No se encontró una multa con el ID proporcionado.");
        }

        // Cerrar la conexión
        cs.close();
        objetoConexion.cerrarConexion();

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Error al eliminar la multa: " + e.getMessage());
    }
}


public String buscarMulta(int idMulta) {
    // Crea una instancia de la clase de conexión a la base de datos
    bd objetoConexion = new bd();
    
    // Construye la consulta SQL manualmente usando concatenación
    String consulta = "SELECT estado_multa, nombre_conductor, placa_vehiculo, marca_vehiculo, linea_vehiculo, color_vehiculo, dpi_conductor FROM multas WHERE id_multa = " + idMulta;
    StringBuilder resultado = new StringBuilder();

    try {
        // Establecer la conexión y verificar que no sea nula
        Connection con = objetoConexion.establecerConexion();
        if (con == null) {
            return "Error: No se pudo establecer la conexión.";
        }

        // Crear el Statement
        Statement stmt = con.createStatement();

        // Ejecutar la consulta
        ResultSet rs = stmt.executeQuery(consulta);

        // Verificar si se encontró una multa
        if (rs.next()) {
            // Recuperar los datos
            String estado = rs.getString("estado_multa");
            String nombreConductor = rs.getString("nombre_conductor");
            String placa = rs.getString("placa_vehiculo");
            String marca = rs.getString("marca_vehiculo");
            String linea = rs.getString("linea_vehiculo");
            String color = rs.getString("color_vehiculo");
            String DPI =  rs.getString("dpi_conductor");
            // Construir el resultado
            resultado.append("Estado: ").append(estado).append("\n")
                     .append("Nombre del Conductor: ").append(nombreConductor).append("\n")
                     .append("Placa: ").append(placa).append("\n")
                     .append("Marca: ").append(marca).append("\n")
                     .append("Línea: ").append(linea).append("\n")
                     .append("Color: ").append(color).append("\n")
                     .append("DPI:  ").append(DPI);
        } else {
            resultado.append("No se encontró una multa con el ID proporcionado.");
        }

        // Cerrar el ResultSet y el Statement
        rs.close();
        stmt.close();
        con.close(); // Cerrar la conexión

    } catch (SQLException e) {
        return "Error al buscar la multa: " + e.getMessage();
    }

    return resultado.toString();
}

}












