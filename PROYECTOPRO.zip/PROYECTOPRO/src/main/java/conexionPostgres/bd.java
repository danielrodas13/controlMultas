/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package conexionPostgres;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

/**
 *
 * @author danie
 */
public class bd {
    Connection conectar = null;
    
    String usuario= "postgres";
     String contraseña= "muni123$";
 String bd= "bdMultas";
 String ip= "localhost";
  String puerto= "5432";
  
  
  String cadena= "jdbc:postgresql://"+ip+":"+puerto+"/"+bd;
  
  
  
  public Connection establecerConexion(){
      
    try {
      Class.forName("org.postgresql.Driver");
              
              conectar= DriverManager.getConnection(cadena,usuario,contraseña);
               JOptionPane.showMessageDialog(null,"se conecto correctamente la base de datos");
             
      
  }catch (Exception e){    
       System.out.println("Conexion Fallida.");
            System.out.println(e.getMessage());
  }
  return conectar;
}

    public void cerrarConexion() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
  
    
}
